package com.example.mini.green.staticData;

/**
 * Created by Param on 30-08-2017.
 */

public class UserAccount {

    String name,address,phoneno,city, pincode,landmark;

    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }

    public String getPhoneno() {
        return phoneno;
    }

    public String getCity() {
        return city;
    }

    public String getLandmark() {
        return landmark;
    }

    public String getPincode() {
        return pincode;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setPhoneno(String phoneno) {
        this.phoneno = phoneno;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public void setLandmark(String landmark) {
        this.landmark = landmark;
    }

    public void setPincode(String pincode) {
        this.pincode = pincode;
    }
}
