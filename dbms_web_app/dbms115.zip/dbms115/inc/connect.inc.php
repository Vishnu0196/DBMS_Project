<?php
$servername = "localhost";
$username = "new";
$password = "1234";

// Create connection
$mysqli = new mysqli($servername, $username, $password, "grocery");

// Check connection
if ($mysqli->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
//echo "Connected successfully";
?>